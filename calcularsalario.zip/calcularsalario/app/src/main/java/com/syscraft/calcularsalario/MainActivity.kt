package com.syscraft.calcularsalario


import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val etNombre = findViewById<EditText>(R.id.etNombre)
        val etSalario = findViewById<EditText>(R.id.etSalario)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)
        val btnNuevo = findViewById<Button>(R.id.btnNuevo)
        val btnSalir = findViewById<Button>(R.id.btnSalir)
        val tvResultados = findViewById<TextView>(R.id.tvResultados)

        btnCalcular.setOnClickListener {
            val nombre = etNombre.text.toString().trim()
            val salarioStr = etSalario.text.toString().trim()

            if(nombre.isEmpty()) {
                Toast.makeText(this, "Ingrese el nombre completo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if(salarioStr.isEmpty()) {
                Toast.makeText(this, "Ingrese el salario mensual", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val salario = salarioStr.toDoubleOrNull()
            if(salario == null || salario <= 0) {
                Toast.makeText(this, "Ingrese un salario válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val inss = salario * 0.07   // 7% INSS
            val ir = salario * 0.10     // 10% IR
            val totalDeduccion = inss + ir
            val salarioNeto = salario - totalDeduccion

            tvResultados.text = """
                Nombre: $nombre
                INSS: $${"%.2f".format(inss)}
                IR: $${"%.2f".format(ir)}
                Total Deducción: $${"%.2f".format(totalDeduccion)}
                Salario Neto: $${"%.2f".format(salarioNeto)}
            """.trimIndent()
        }

        btnNuevo.setOnClickListener {
            etNombre.text.clear()
            etSalario.text.clear()
            tvResultados.text = "Resultados"
        }

        btnSalir.setOnClickListener {
            finish()
        }
    }
}
